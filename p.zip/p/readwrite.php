<?php
if (isset($_GET['path'])) {
    $path = $_GET['path'];
    if (is_writable($path)) {
        echo "Writable";
    } else {
        echo "Not Writable";
    }
} else {
    echo "No path provided. Usage: code.php?path=/home/pub";
}
?>