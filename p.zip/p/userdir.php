<?php
if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
    $user = posix_getpwuid(posix_geteuid());
    echo "User Directory: " . $user['dir'];
} else {
    echo "Function disabled";
}
?>