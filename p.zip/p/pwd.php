<?php
echo getcwd();
?>