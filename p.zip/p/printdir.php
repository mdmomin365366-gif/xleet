<?php
$skip = ['wp-admin', 'wp-content', 'wp-includes', '.', '..'];

function scanDirs($path, $depth = 0, $maxDepth = 7, $skip = []) {
    if ($depth > $maxDepth) return;
    if (!is_dir($path)) return;

    $items = @scandir($path);
    if (!$items) return;

    foreach ($items as $item) {
        if (in_array($item, $skip)) continue;
        $full = $path . '/' . $item;
        if (is_dir($full)) {
            $pad = str_repeat('&nbsp;&nbsp;&nbsp;', $depth);
            echo $pad . $full . '<br>';
            scanDirs($full, $depth + 1, $maxDepth, $skip);
        }
    }
}

if (isset($_GET['path'])) {
    scanDirs($_GET['path'], 0, 7, $skip);
} else {
    echo 'Usage: code.php?path=/home/user';
}
?>